<?php
require "includes/common.php";
?>
<!DOCTYPE html>

<html>
    <head>
        <title>About Us | Phone-Stop.com</title>
        <link rel="shortcut icon" href="img\srtcticon.png" type="image/png">
        
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Raleway">
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link href="css/bootstrap.css" rel="stylesheet">
        <!-- Custom CSS -->
        <link href="css/style.css" rel="stylesheet">
        <!-- jQuery -->
        <script src="js/jquery.js"></script>
        <!-- Bootstrap Core JavaScript -->
        <script src="js/bootstrap.min.js"></script>
    </head>
    
      
<body>
       <!-- Header -->
    <?php include 'includes/header.php'; ?>
    <br>
        <hr>
        <div style="margin-left: 30px;">
        <h4><b>W</b>e are the in the final years during the making of this page,and the only purpose was to provide easy and hasle free programming to others.   </h4>
        <h4><b>W</b>e made this page on the basis of bootstrap,html and PHP and used many sources.</h4>
        <h4><b>N</b>ow the idea of such page came from internshala php course , which helped a lot during the making of the page.</h4>
        <h4><b>T</b>his page consists of main page,cart where you can buy stuffs and many other features also. </h4>
        <h4><b>T</b>his page is a subpart of the main page ,check out various more links over there.</h4>
        </div>
        <hr />
        <h3 class="w3-center"><b>CONTACT</b></h3>
         
  <p class="w3-center w3-large">Lets get in touch. Send us a message:</p>
  <div style="margin-top:48px">
    <p><i class="fa fa-map-marker fa-fw w3-xxlarge w3-margin-right"></i> Kolkata, INDIA</p>
    <p><i class="fa fa-phone fa-fw w3-xxlarge w3-margin-right"></i> Phone: +91 8910812580</p>
     <p><i class="fa fa-envelope fa-fw w3-xxlarge w3-margin-right"> </i> Email: kkumaribest7@gmail.com</p>
    <p><i class="fa fa-envelope fa-fw w3-xxlarge w3-margin-right"> </i> Email: mekaranyadav8@gmail.com</p>
    <br>
</div>
<br />
        </div>
        <?php include 'includes/footer.php'; ?>
    </body>
</html>
